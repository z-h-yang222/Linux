#define _GNU_SOURCE
#ifdef HAVE_READLINE
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>
#include <readline/history.h>

#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>

#include "input.h"
#include "history.h"
#include "alias.h"

// --- PATH command cache (simple) ---
static char **g_path_cmds = NULL;
static int g_path_n = 0;

static int is_executable_file(const char *p) {
    struct stat st;
    if (stat(p, &st) < 0) return 0;
    if (!S_ISREG(st.st_mode)) return 0;
    return (access(p, X_OK) == 0);
}

static int str_in_list(char **v, int n, const char *s) {
    for (int i=0;i<n;i++) if (strcmp(v[i], s) == 0) return 1;
    return 0;
}

static void add_cmd(const char *name) {
    if (!name || !*name) return;
    if (strchr(name, '/')) return;
    if (str_in_list(g_path_cmds, g_path_n, name)) return;
    g_path_cmds = realloc(g_path_cmds, (size_t)(g_path_n + 1) * sizeof(char*));
    if (!g_path_cmds) return;
    g_path_cmds[g_path_n++] = strdup(name);
}

static void build_path_cache_once(void) {
    if (g_path_cmds) return;
    const char *path = getenv("PATH");
    if (!path) return;

    char *dup = strdup(path);
    if (!dup) return;
    for (char *tok = strtok(dup, ":"); tok; tok = strtok(NULL, ":")) {
        DIR *d = opendir(tok);
        if (!d) continue;
        struct dirent *e;
        while ((e = readdir(d))) {
            if (!e->d_name || e->d_name[0] == '.') continue;
            char full[4096];
            snprintf(full, sizeof(full), "%s/%s", tok, e->d_name);
            if (is_executable_file(full)) add_cmd(e->d_name);
        }
        closedir(d);
    }
    free(dup);
}

static char *xhell_cmd_generator(const char *text, int state) {
    static int bidx, aidx, pidx, len;
    const char **builtins = hist_builtin_list();
    const char **aliases = alias_name_list();

    if (!state) {
        build_path_cache_once();
        bidx = 0; aidx = 0; pidx = 0;
        len = (int)strlen(text);
    }

    const char *name;
    while ((name = builtins[bidx++])) {
        if (strncmp(name, text, (size_t)len) == 0) return strdup(name);
    }
    while (aliases && (name = aliases[aidx++])) {
        if (strncmp(name, text, (size_t)len) == 0) return strdup(name);
    }
    while (g_path_cmds && pidx < g_path_n) {
        name = g_path_cmds[pidx++];
        if (strncmp(name, text, (size_t)len) == 0) return strdup(name);
    }
    return NULL;
}

static char **xhell_completion(const char *text, int start, int end) {
    (void)end;
    if (start == 0) {
        char **matches = rl_completion_matches(text, xhell_cmd_generator);
        rl_attempted_completion_over = 0;
        return matches;
    }

    // For arguments: fallback to filename completion.
    rl_attempted_completion_over = 0;
    return rl_completion_matches(text, rl_filename_completion_function);
}

void xhell_input_init(void) {
    rl_attempted_completion_function = xhell_completion;
}

char *xhell_readline(const char *prompt) {
    return readline(prompt);
}

void xhell_add_history(const char *line) {
    if (line && *line) add_history(line);
}

#endif
