#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/stat.h>
#include <limits.h>

#include "util.h"

char *xstrdup(const char *s) {
    if (!s) return NULL;
    char *p = strdup(s);
    if (!p) {
        perror("strdup");
        exit(1);
    }
    return p;
}

void *xcalloc(size_t n, size_t sz) {
    void *p = calloc(n, sz);
    if (!p) {
        perror("calloc");
        exit(1);
    }
    return p;
}

// --- word splitting (for alias expansion / helper commands) ---

static char *read_quoted(const char **ps, char quote) {
    const char *s = *ps;
    // s points to quote
    s++;
    const char *start = s;
    while (*s && *s != quote) s++;
    if (*s != quote) { errno = EINVAL; return NULL; }
    size_t len = (size_t)(s - start);
    char *out = (char*)xcalloc(len + 1, 1);
    memcpy(out, start, len);
    out[len] = '\0';
    *ps = s + 1;
    return out;
}

int split_words(const char *line, char ***out_argv, int *out_argc, int max_args) {
    if (!line || !out_argv || !out_argc || max_args <= 0) { errno = EINVAL; return -1; }
    *out_argv = NULL; *out_argc = 0;

    char **argv = (char**)xcalloc((size_t)max_args + 1, sizeof(char*));
    int argc = 0;

    const char *s = line;
    while (*s) {
        while (*s && isspace((unsigned char)*s)) s++;
        if (!*s) break;
        if (argc >= max_args) {
            for (int i=0;i<argc;i++) free(argv[i]);
            free(argv);
            errno = E2BIG;
            return -1;
        }

        char *w = NULL;
        if (*s == '\'' || *s == '"') {
            w = read_quoted(&s, *s);
        } else {
            const char *start = s;
            while (*s && !isspace((unsigned char)*s)) s++;
            size_t len = (size_t)(s - start);
            w = (char*)xcalloc(len + 1, 1);
            memcpy(w, start, len);
            w[len] = '\0';
        }
        if (!w) {
            int e = errno;
            for (int i=0;i<argc;i++) free(argv[i]);
            free(argv);
            errno = e;
            return -1;
        }
        argv[argc++] = w;
        argv[argc] = NULL;
    }

    *out_argv = argv;
    *out_argc = argc;
    return 0;
}

// --- git branch ---

static int file_exists(const char *p) {
    struct stat st;
    return (stat(p, &st) == 0);
}

static int read_first_line(const char *path, char *out, size_t out_sz) {
    FILE *f = fopen(path, "r");
    if (!f) return -1;
    if (!fgets(out, (int)out_sz, f)) { fclose(f); errno = EIO; return -1; }
    fclose(f);
    // trim
    size_t n = strlen(out);
    while (n > 0 && (out[n-1] == '\n' || out[n-1] == '\r')) out[--n] = '\0';
    return 0;
}

int get_git_branch(char *out, size_t out_sz) {
    if (!out || out_sz == 0) { errno = EINVAL; return -1; }
    out[0] = '\0';

    char cwd[PATH_MAX];
    if (!getcwd(cwd, sizeof(cwd))) return -1;

    // walk up to find .git
    char path[PATH_MAX];
    snprintf(path, sizeof(path), "%s", cwd);
    for (int depth=0; depth<32; depth++) {
        char gitdir[PATH_MAX];
        snprintf(gitdir, sizeof(gitdir), "%s/.git", path);
        if (file_exists(gitdir)) {
            char head[PATH_MAX];
            snprintf(head, sizeof(head), "%s/HEAD", gitdir);
            char line[256];
            if (read_first_line(head, line, sizeof(line)) < 0) return -1;
            const char *prefix = "ref: refs/heads/";
            if (strncmp(line, prefix, strlen(prefix)) == 0) {
                snprintf(out, out_sz, "%s", line + strlen(prefix));
                return 0;
            }
            // detached: show short hash
            if (strlen(line) >= 7) {
                char shorty[8] = {0};
                memcpy(shorty, line, 7);
                snprintf(out, out_sz, "%s", shorty);
                return 0;
            }
            return -1;
        }

        // go to parent
        char *slash = strrchr(path, '/');
        if (!slash) break;
        if (slash == path) { // reached /
            break;
        }
        *slash = '\0';
    }
    errno = ENOENT;
    return -1;
}
