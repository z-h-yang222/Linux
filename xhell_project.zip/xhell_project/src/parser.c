#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>

#include "parser.h"
#include "util.h"

typedef struct {
    char **v;
    int n;
    int cap;
} Vec;

static void vec_push(Vec *a, char *s) {
    if (a->n + 1 >= a->cap) {
        a->cap = a->cap ? a->cap * 2 : 16;
        a->v = realloc(a->v, (size_t)a->cap * sizeof(char*));
        if (!a->v) { errno = ENOMEM; return; }
    }
    a->v[a->n++] = s;
    a->v[a->n] = NULL;
}

static char *read_quoted(const char **ps, char quote) {
    const char *s = *ps; // s points to quote char
    s++; // after quote
    const char *start = s;
    while (*s && *s != quote) s++;
    if (*s != quote) { errno = EINVAL; return NULL; }
    size_t len = (size_t)(s - start);
    char *out = (char*)xcalloc(len + 1, 1);
    memcpy(out, start, len);
    out[len] = '\0';
    *ps = s + 1;
    return out;
}

static char *read_word(const char **ps) {
    const char *s = *ps;
    Vec parts = {0};
    while (*s && !isspace((unsigned char)*s) && *s!='|' && *s!='>' && *s!='<' && *s!='&') {
        if (*s=='"' || *s=='\'') {
            char q = *s;
            char *seg = read_quoted(&s, q);
            if (!seg) { // errno set
                // cleanup
                if (parts.v) { for (int i=0;i<parts.n;i++) free(parts.v[i]); free(parts.v); }
                return NULL;
            }
            vec_push(&parts, seg);
        } else {
            const char *start = s;
            while (*s && !isspace((unsigned char)*s) && *s!='|' && *s!='>' && *s!='<' && *s!='&' && *s!='"' && *s!='\'') s++;
            size_t len = (size_t)(s - start);
            char *seg = (char*)xcalloc(len + 1, 1);
            memcpy(seg, start, len);
            seg[len] = '\0';
            vec_push(&parts, seg);
        }
    }

    // concat parts
    size_t total = 0;
    for (int i=0;i<parts.n;i++) total += strlen(parts.v[i]);
    char *out = (char*)xcalloc(total + 1, 1);
    for (int i=0;i<parts.n;i++) strcat(out, parts.v[i]);

    if (parts.v) { for (int i=0;i<parts.n;i++) free(parts.v[i]); free(parts.v); }
    *ps = s;
    return out;
}

static void init_cmd(Cmd *c) {
    memset(c, 0, sizeof(*c));
}

static int add_arg(Cmd *c, char *arg) {
    if (c->argc + 2 >= XHELL_MAX_ARGS) { errno = E2BIG; return -1; }
    if (!c->argv) {
        c->argv = (char**)xcalloc(XHELL_MAX_ARGS, sizeof(char*));
    }
    c->argv[c->argc++] = arg;
    c->argv[c->argc] = NULL;
    return 0;
}

static int ensure_cmd_has_argv(Cmd *c) {
    if (!c->argv || !c->argv[0]) { errno = EINVAL; return -1; }
    return 0;
}

int parse_line(const char *line, Pipeline *out) {
    if (!line || !out) { errno = EINVAL; return -1; }
    memset(out, 0, sizeof(*out));

    Cmd cmds[XHELL_MAX_PIPE];
    int ncmd = 0;
    init_cmd(&cmds[ncmd]);

    const char *s = line;

    while (*s) {
        while (isspace((unsigned char)*s)) s++;
        if (*s == '\0') break;

        // background (only accept at end)
        if (*s == '&') {
            out->background = true;
            s++;
            while (isspace((unsigned char)*s)) s++;
            if (*s != '\0') { errno = EINVAL; return -1; }
            break;
        }

        // pipe
        if (*s == '|') {
            if (ensure_cmd_has_argv(&cmds[ncmd]) != 0) return -1;
            ncmd++;
            if (ncmd >= XHELL_MAX_PIPE) { errno = E2BIG; return -1; }
            init_cmd(&cmds[ncmd]);
            s++;
            continue;
        }

        // redirections
        if (*s == '<') {
            s++;
            while (isspace((unsigned char)*s)) s++;
            char *w = read_word(&s);
            if (!w) return -1;
            free(cmds[ncmd].in_file);
            cmds[ncmd].in_file = w;
            continue;
        }

        if (*s == '>') {
            int append = 0;
            s++;
            if (*s == '>') { append = 1; s++; }
            while (isspace((unsigned char)*s)) s++;
            char *w = read_word(&s);
            if (!w) return -1;
            free(cmds[ncmd].out_file);
            cmds[ncmd].out_file = w;
            cmds[ncmd].out_append = append;
            continue;
        }

        // stderr redirection: 2> / 2>>
        if (*s == '2' && *(s+1) == '>') {
            int append = 0;
            s += 2;
            if (*s == '>') { append = 1; s++; }
            while (isspace((unsigned char)*s)) s++;
            char *w = read_word(&s);
            if (!w) return -1;
            free(cmds[ncmd].err_file);
            cmds[ncmd].err_file = w;
            cmds[ncmd].err_append = append;
            continue;
        }

        // normal word
        char *w = NULL;
        if (*s == '"' || *s == '\'') {
            w = read_quoted(&s, *s);
        } else {
            w = read_word(&s);
        }
        if (!w) return -1;
        if (add_arg(&cmds[ncmd], w) != 0) return -1;
    }

    if (ensure_cmd_has_argv(&cmds[ncmd]) != 0) return -1;
    ncmd++;

    out->cmds = (Cmd*)xcalloc((size_t)ncmd, sizeof(Cmd));
    out->ncmds = ncmd;
    for (int i=0;i<ncmd;i++) out->cmds[i] = cmds[i];

    return 0;
}
