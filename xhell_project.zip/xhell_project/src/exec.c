#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <signal.h>

#include "exec.h"
#include "builtins.h"
#include "alias.h"
#include "logger.h"
#include "jobs.h"
#include "util.h"

static void free_argv(char **argv) {
    if (!argv) return;
    for (int i=0; argv[i]; i++) free(argv[i]);
    free(argv);
}

// Expand alias on the first word of a command:  foo arg1 arg2
// alias foo="bar --x"  -> bar --x arg1 arg2
// Limit nesting to avoid recursion.
static void expand_alias_cmd(Cmd *c) {
    if (!c || !c->argv || !c->argv[0]) return;
    for (int depth=0; depth<8; depth++) {
        const char *val = alias_lookup(c->argv[0]);
        if (!val) return;

        char **a_argv = NULL;
        int a_argc = 0;
        if (split_words(val, &a_argv, &a_argc, XHELL_MAX_ARGS) < 0) {
            // bad alias value: ignore expansion
            return;
        }
        if (a_argc == 0) { free_argv(a_argv); return; }

        // merge: alias words + original tail
        int tail = c->argc - 1;
        int new_argc = a_argc + tail;
        if (new_argc >= XHELL_MAX_ARGS) {
            free_argv(a_argv);
            return;
        }

        char **newv = (char**)xcalloc((size_t)XHELL_MAX_ARGS, sizeof(char*));
        int k = 0;
        for (int i=0;i<a_argc;i++) newv[k++] = xstrdup(a_argv[i]);
        for (int i=1;i<c->argc;i++) newv[k++] = xstrdup(c->argv[i]);
        newv[k] = NULL;

        free_argv(a_argv);
        free_argv(c->argv);
        c->argv = newv;
        c->argc = k;
        // loop to allow nested alias on the new argv[0]
    }
}

static void expand_alias_pipeline(Pipeline *p) {
    if (!p || !p->cmds) return;
    for (int i=0;i<p->ncmds;i++) expand_alias_cmd(&p->cmds[i]);
}

static int open_redir_out(const char *file, int append) {
    int flags = O_WRONLY | O_CREAT | (append ? O_APPEND : O_TRUNC);
    return open(file, flags, 0644);
}

static int apply_redirs(Cmd *c) {
    if (c->in_file) {
        int fd = open(c->in_file, O_RDONLY);
        if (fd < 0) return -1;
        if (dup2(fd, STDIN_FILENO) < 0) { close(fd); return -1; }
        close(fd);
    }
    if (c->out_file) {
        int fd = open_redir_out(c->out_file, c->out_append);
        if (fd < 0) return -1;
        if (dup2(fd, STDOUT_FILENO) < 0) { close(fd); return -1; }
        close(fd);
    }
    if (c->err_file) {
        int fd = open_redir_out(c->err_file, c->err_append);
        if (fd < 0) return -1;
        if (dup2(fd, STDERR_FILENO) < 0) { close(fd); return -1; }
        close(fd);
    }
    return 0;
}

static int run_builtin_in_current(Cmd *c) {
    int saved_stdin = dup(STDIN_FILENO);
    int saved_stdout = dup(STDOUT_FILENO);
    int saved_stderr = dup(STDERR_FILENO);
    if (saved_stdin < 0 || saved_stdout < 0 || saved_stderr < 0) return 1;

    int rc = 1;

    fflush(stdout);
    fflush(stderr);

    if (apply_redirs(c) < 0) {
        int e = errno;
        perror(c->argv[0]);
        log_error(e, "builtin redir failed: %s", c->argv[0]);
        goto restore;
    }
    rc = run_builtin(c);
    if (rc < 0) {
        int e = errno;
        perror(c->argv[0]);
        log_error(e, "builtin failed: %s", c->argv[0]);
        rc = 1;
    }

    fflush(stdout);
    fflush(stderr);

restore:
    dup2(saved_stdin, STDIN_FILENO);
    dup2(saved_stdout, STDOUT_FILENO);
    dup2(saved_stderr, STDERR_FILENO);
    close(saved_stdin); close(saved_stdout); close(saved_stderr);
    return rc;
}

static void child_exec(Cmd *c) {
    if (apply_redirs(c) < 0) {
        perror(c->argv[0]);
        _exit(1);
    }

    if (is_builtin(c->argv[0]) && !is_parent_only_builtin(c->argv[0])) {
        int rc = run_builtin(c);
        if (rc < 0) {
            perror(c->argv[0]);
            _exit(1);
        }
        _exit(rc);
    }

    execvp(c->argv[0], c->argv);
    perror(c->argv[0]);
    _exit(127);
}

int exec_pipeline(Pipeline *p) {
    if (!p || p->ncmds <= 0) return 0;

    // alias expansion (first word of each simple command)
    expand_alias_pipeline(p);

    // parent-only builtin (no pipe)
    if (p->ncmds == 1 && is_builtin(p->cmds[0].argv[0]) && is_parent_only_builtin(p->cmds[0].argv[0])) {
        int st = run_builtin_in_current(&p->cmds[0]);
        if (builtin_requests_exit()) return st; // handled by caller
        return st;
    }

    // single non-parent-only builtin can run in parent for efficiency (still honors redir)
    if (p->ncmds == 1 && is_builtin(p->cmds[0].argv[0]) && !is_parent_only_builtin(p->cmds[0].argv[0])) {
        return run_builtin_in_current(&p->cmds[0]);
    }

    int pipes[2*(XHELL_MAX_PIPE-1)];
    memset(pipes, -1, sizeof(pipes));
    for (int i=0;i<p->ncmds-1;i++) {
        if (pipe(&pipes[2*i]) < 0) {
            perror("pipe");
            return 1;
        }
    }

    pid_t pids[XHELL_MAX_PIPE] = {0};
    pid_t pgid = 0;

    for (int i=0;i<p->ncmds;i++) {
        pid_t pid = fork();
        if (pid < 0) {
            perror("fork");
            return 1;
        }
        if (pid == 0) {
            // child: restore default signals for interactive
            signal(SIGINT, SIG_DFL);
            signal(SIGQUIT, SIG_DFL);

            // process group
            if (i == 0) setpgid(0, 0);
            else setpgid(0, pgid);

            // connect pipes
            if (i > 0) {
                dup2(pipes[2*(i-1)], STDIN_FILENO);
            }
            if (i < p->ncmds - 1) {
                dup2(pipes[2*i + 1], STDOUT_FILENO);
            }

            // close all pipe fds
            for (int k=0;k<2*(p->ncmds-1);k++) close(pipes[k]);

            child_exec(&p->cmds[i]);
        } else {
            if (i == 0) {
                pgid = pid;
                setpgid(pid, pgid);
            } else {
                setpgid(pid, pgid);
            }
            pids[i] = pid;
        }
    }

    // close pipes in parent
    for (int k=0;k<2*(p->ncmds-1);k++) close(pipes[k]);

    if (p->background) {
        int job_id = jobs_add(pgid, p->rawline ? p->rawline : "");
        printf("[%d] %d\n", job_id, (int)pgid);
        return 0;
    }

    int status = 0, last = 0;
    for (int i=0;i<p->ncmds;i++) {
        if (waitpid(pids[i], &status, 0) < 0) {
            perror("waitpid");
            return 1;
        }
        if (i == p->ncmds - 1) last = status;
    }

    if (WIFEXITED(last)) return WEXITSTATUS(last);
    if (WIFSIGNALED(last)) return 128 + WTERMSIG(last);
    return 1;
}
