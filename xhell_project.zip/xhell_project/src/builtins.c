#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include <libgen.h>

#include "builtins.h"
#include "history.h"
#include "logger.h"
#include "jobs.h"
#include "alias.h"
#include "parser.h"
#include "exec.h"
#include "util.h"

static int g_exit_requested = 0;
static char g_prev_dir[4096] = {0};

static void set_prev_dir(const char *path) {
    if (!path) return;
    snprintf(g_prev_dir, sizeof(g_prev_dir), "%s", path);
}

int builtin_requests_exit(void) {
    return g_exit_requested;
}

int is_builtin(const char *name) {
    if (!name) return 0;
    const char **b = hist_builtin_list();
    for (int i=0; b[i]; i++) if (strcmp(b[i], name) == 0) return 1;
    return 0;
}

int is_parent_only_builtin(const char *name) {
    if (!name) return 0;
    // must run in parent: affects shell state or in-memory config
    return (strcmp(name, "xcd")==0 ||
            strcmp(name, "xalias")==0 || strcmp(name, "xunalias")==0 ||
            strcmp(name, "xsource")==0 ||
            strcmp(name, "quit")==0);
}

/* -------- helpers -------- */

static int copy_file(const char *src, const char *dst) {
    int fdin = open(src, O_RDONLY);
    if (fdin < 0) return -1;

    int fdout = open(dst, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fdout < 0) { close(fdin); return -1; }

    char buf[8192];
    ssize_t n;
    while ((n = read(fdin, buf, sizeof(buf))) > 0) {
        ssize_t off = 0;
        while (off < n) {
            ssize_t w = write(fdout, buf + off, (size_t)(n - off));
            if (w < 0) { close(fdin); close(fdout); return -1; }
            off += w;
        }
    }
    if (n < 0) { close(fdin); close(fdout); return -1; }
    close(fdin);
    close(fdout);
    return 0;
}

static int ensure_dir(const char *path, mode_t mode) {
    struct stat st;
    if (stat(path, &st) == 0) {
        if (S_ISDIR(st.st_mode)) return 0;
        errno = ENOTDIR;
        return -1;
    }
    if (mkdir(path, mode) < 0) return -1;
    return 0;
}

static int copy_dir_recursive(const char *src, const char *dst) {
    struct stat st;
    if (stat(src, &st) < 0) return -1;
    if (!S_ISDIR(st.st_mode)) { errno = ENOTDIR; return -1; }
    if (ensure_dir(dst, st.st_mode & 0777) < 0) return -1;

    DIR *d = opendir(src);
    if (!d) return -1;
    struct dirent *e;
    while ((e = readdir(d))) {
        if (strcmp(e->d_name, ".")==0 || strcmp(e->d_name, "..")==0) continue;
        char s_path[4096], d_path[4096];
        snprintf(s_path, sizeof(s_path), "%s/%s", src, e->d_name);
        snprintf(d_path, sizeof(d_path), "%s/%s", dst, e->d_name);

        if (lstat(s_path, &st) < 0) { closedir(d); return -1; }
        if (S_ISDIR(st.st_mode)) {
            if (copy_dir_recursive(s_path, d_path) < 0) { closedir(d); return -1; }
        } else if (S_ISREG(st.st_mode)) {
            if (copy_file(s_path, d_path) < 0) { closedir(d); return -1; }
        } else {
            // skip special files
        }
    }
    closedir(d);
    return 0;
}

static int rm_dir_recursive(const char *path) {
    DIR *d = opendir(path);
    if (!d) return -1;
    struct dirent *e;
    struct stat st;
    while ((e = readdir(d))) {
        if (strcmp(e->d_name, ".")==0 || strcmp(e->d_name, "..")==0) continue;
        char p[4096];
        snprintf(p, sizeof(p), "%s/%s", path, e->d_name);
        if (lstat(p, &st) < 0) { closedir(d); return -1; }
        if (S_ISDIR(st.st_mode)) {
            if (rm_dir_recursive(p) < 0) { closedir(d); return -1; }
            if (rmdir(p) < 0) { closedir(d); return -1; }
        } else {
            if (unlink(p) < 0) { closedir(d); return -1; }
        }
    }
    closedir(d);
    return 0;
}

static void mode_str(mode_t m, char out[11]) {
    out[0] = S_ISDIR(m) ? 'd' : S_ISLNK(m) ? 'l' : '-';
    out[1] = (m & S_IRUSR) ? 'r' : '-';
    out[2] = (m & S_IWUSR) ? 'w' : '-';
    out[3] = (m & S_IXUSR) ? 'x' : '-';
    out[4] = (m & S_IRGRP) ? 'r' : '-';
    out[5] = (m & S_IWGRP) ? 'w' : '-';
    out[6] = (m & S_IXGRP) ? 'x' : '-';
    out[7] = (m & S_IROTH) ? 'r' : '-';
    out[8] = (m & S_IWOTH) ? 'w' : '-';
    out[9] = (m & S_IXOTH) ? 'x' : '-';
    out[10] = '\0';
}

/* -------- builtins -------- */

static int bi_xpwd(Cmd *cmd) {
    (void)cmd;
    char buf[4096];
    if (!getcwd(buf, sizeof(buf))) return -1;
    printf("%s\n", buf);
    return 0;
}

static int bi_xcd(Cmd *cmd) {
    const char *target = NULL;
    if (cmd->argc < 2) {
        target = getenv("HOME");
        if (!target) target = "/";
    } else {
        target = cmd->argv[1];
        if (strcmp(target, "-") == 0) {
            if (g_prev_dir[0] == '\0') { errno = ENOENT; return -1; }
            target = g_prev_dir;
        }
    }

    char cur[4096];
    if (getcwd(cur, sizeof(cur))) set_prev_dir(cur);

    if (chdir(target) < 0) return -1;
    return 0;
}

static int bi_xls(Cmd *cmd) {
    int longfmt = 0;
    const char *path = ".";
    if (cmd->argc >= 2) {
        int idx = 1;
        if (strcmp(cmd->argv[idx], "-l") == 0) { longfmt = 1; idx++; }
        if (idx < cmd->argc) path = cmd->argv[idx];
    }

    DIR *d = opendir(path);
    if (!d) return -1;

    struct dirent *e;
    while ((e = readdir(d))) {
        if (strcmp(e->d_name, ".")==0 || strcmp(e->d_name, "..")==0) continue;
        char full[4096];
        snprintf(full, sizeof(full), "%s/%s", path, e->d_name);

        struct stat st;
        if (lstat(full, &st) < 0) { closedir(d); return -1; }

        if (!longfmt) {
            if (S_ISDIR(st.st_mode)) printf("Dir: %s/\n", e->d_name);
            else printf("File: %s\n", e->d_name);
        } else {
            char ms[11]; mode_str(st.st_mode, ms);
            char tbuf[64];
            struct tm tm;
            localtime_r(&st.st_mtime, &tm);
            strftime(tbuf, sizeof(tbuf), "%b %d %H:%M", &tm);
            printf("%s %8ld %s %s%s\n", ms, (long)st.st_size, tbuf, e->d_name, S_ISDIR(st.st_mode)?"/":"");
        }
    }
    closedir(d);
    return 0;
}

static int bi_xtouch(Cmd *cmd) {
    if (cmd->argc < 2) { errno = EINVAL; return -1; }
    const char *file = cmd->argv[1];
    int fd = open(file, O_WRONLY | O_CREAT | O_EXCL, 0644);
    if (fd < 0) {
        if (errno == EEXIST) return 0;
        return -1;
    }
    close(fd);
    return 0;
}

static int bi_xecho(Cmd *cmd) {
    for (int i=1;i<cmd->argc;i++) {
        if (i>1) putchar(' ');
        fputs(cmd->argv[i], stdout);
    }
    putchar('\n');
    return 0;
}

static int bi_xcat(Cmd *cmd) {
    if (cmd->argc < 2) { errno = EINVAL; return -1; }
    const char *file = cmd->argv[1];
    int fd = open(file, O_RDONLY);
    if (fd < 0) return -1;
    char buf[8192];
    ssize_t n;
    while ((n = read(fd, buf, sizeof(buf))) > 0) {
        ssize_t off = 0;
        while (off < n) {
            ssize_t w = write(STDOUT_FILENO, buf + off, (size_t)(n - off));
            if (w < 0) { close(fd); return -1; }
            off += w;
        }
    }
    if (n < 0) { close(fd); return -1; }
    close(fd);
    return 0;
}

static int bi_xcp(Cmd *cmd) {
    int recursive = 0;
    int idx = 1;
    if (cmd->argc >= 2 && strcmp(cmd->argv[1], "-r") == 0) { recursive = 1; idx++; }
    if (cmd->argc < idx + 2) { errno = EINVAL; return -1; }
    const char *src = cmd->argv[idx];
    const char *dst = cmd->argv[idx+1];

    struct stat st;
    if (lstat(src, &st) < 0) return -1;

    if (S_ISDIR(st.st_mode)) {
        if (!recursive) { errno = EISDIR; return -1; }
        return copy_dir_recursive(src, dst);
    }
    return copy_file(src, dst);
}

static int bi_xrm(Cmd *cmd) {
    int recursive = 0;
    int idx = 1;
    if (cmd->argc >= 2 && strcmp(cmd->argv[1], "-r") == 0) { recursive = 1; idx++; }
    if (cmd->argc < idx + 1) { errno = EINVAL; return -1; }
    const char *path = cmd->argv[idx];

    struct stat st;
    if (lstat(path, &st) < 0) return -1;

    if (S_ISDIR(st.st_mode)) {
        if (!recursive) { errno = EISDIR; return -1; }
        if (rm_dir_recursive(path) < 0) return -1;
        return rmdir(path);
    }
    return unlink(path);
}

static int bi_xmv(Cmd *cmd) {
    int recursive = 0;
    int idx = 1;
    if (cmd->argc >= 2 && strcmp(cmd->argv[1], "-r") == 0) { recursive = 1; idx++; }
    if (cmd->argc < idx + 2) { errno = EINVAL; return -1; }
    const char *src = cmd->argv[idx];
    const char *dst = cmd->argv[idx+1];

    if (rename(src, dst) == 0) return 0;

    // cross-device: copy then remove
    int saved = errno;
    struct stat st;
    if (lstat(src, &st) < 0) return -1;

    if (S_ISDIR(st.st_mode)) {
        if (!recursive) { errno = EISDIR; return -1; }
        if (copy_dir_recursive(src, dst) < 0) return -1;
        if (rm_dir_recursive(src) < 0) return -1;
        if (rmdir(src) < 0) return -1;
    } else {
        if (copy_file(src, dst) < 0) return -1;
        if (unlink(src) < 0) return -1;
    }
    (void)saved;
    return 0;
}

static int bi_xhistory(Cmd *cmd) {
    (void)cmd;
    hist_print();
    return 0;
}

static int bi_xtee(Cmd *cmd) {
    if (cmd->argc < 2) { errno = EINVAL; return -1; }
    const char *file = cmd->argv[1];
    int fd = open(file, O_WRONLY|O_CREAT|O_TRUNC, 0644);
    if (fd < 0) return -1;

    char buf[4096];
    ssize_t n;
    while ((n = read(STDIN_FILENO, buf, sizeof(buf))) > 0) {
        // stdout
        ssize_t off = 0;
        while (off < n) {
            ssize_t w = write(STDOUT_FILENO, buf + off, (size_t)(n - off));
            if (w < 0) { close(fd); return -1; }
            off += w;
        }
        // file
        off = 0;
        while (off < n) {
            ssize_t w = write(fd, buf + off, (size_t)(n - off));
            if (w < 0) { close(fd); return -1; }
            off += w;
        }
    }
    if (n < 0) { close(fd); return -1; }
    close(fd);
    return 0;
}

static int bi_xjournalctl(Cmd *cmd) {
    (void)cmd;
    const char *path = log_path();
    int fd = open(path, O_RDONLY);
    if (fd < 0) return -1;
    char buf[8192];
    ssize_t n;
    while ((n = read(fd, buf, sizeof(buf))) > 0) {
        ssize_t off = 0;
        while (off < n) {
            ssize_t w = write(STDOUT_FILENO, buf + off, (size_t)(n - off));
            if (w < 0) { close(fd); return -1; }
            off += w;
        }
    }
    if (n < 0) { close(fd); return -1; }
    close(fd);
    return 0;
}

/* ---- extras ---- */

static int bi_xhelp(Cmd *cmd) {
    (void)cmd;
    printf("\033[1;33mXhell builtins (cheat sheet)\033[0m\n\n");
    printf("\033[1;36mFilesystem\033[0m\n");
    printf("  xpwd | xcd [path|-] | xls [-l] [path]\n");
    printf("  xtouch <file> | xcat <file> | xecho <...>\n");
    printf("  xcp [-r] <src> <dst> | xmv [-r] <src> <dst> | xrm [-r] <path>\n\n");

    printf("\033[1;36mPipelines / Redirect\033[0m\n");
    printf("  cmd1 | cmd2 | cmd3\n");
    printf("  > / >>  (stdout), 2> / 2>> (stderr)\n\n");

    printf("\033[1;36mHistory / Logs\033[0m\n");
    printf("  xhistory | xjournalctl | xtee <file>\n\n");

    printf("\033[1;36mJobs\033[0m\n");
    printf("  cmd &   (background)\n");
    printf("  xjobs | xfg <id> | xkill <id>\n\n");

    printf("\033[1;36mProductivity (extra卷)\033[0m\n");
    printf("  xalias [name=\"value\"] | xunalias <name> | xwhich <name>\n");
    printf("  xsource <file>  (run commands from file inside current shell)\n");
    printf("  xmenu  (interactive command menu)\n");
    printf("  quit\n");
    return 0;
}

static int bi_xalias(Cmd *cmd) {
    if (cmd->argc == 1) {
        alias_print();
        return 0;
    }
    // support: xalias name="value"  (single arg containing '=')
    const char *arg1 = cmd->argv[1];
    const char *eq = strchr(arg1, '=');
    if (eq) {
        char name[256];
        size_t n = (size_t)(eq - arg1);
        if (n == 0 || n >= sizeof(name)) { errno = EINVAL; return -1; }
        memcpy(name, arg1, n);
        name[n] = '\0';
        const char *val = eq + 1;
        if (alias_set(name, val) < 0) return -1;
        return 0;
    }
    // support: xalias name value...
    if (cmd->argc < 3) { errno = EINVAL; return -1; }
    const char *name = cmd->argv[1];
    // join argv[2..] with spaces
    size_t total = 0;
    for (int i=2;i<cmd->argc;i++) total += strlen(cmd->argv[i]) + 1;
    char *val = (char*)xcalloc(total + 1, 1);
    for (int i=2;i<cmd->argc;i++) {
        strcat(val, cmd->argv[i]);
        if (i != cmd->argc - 1) strcat(val, " ");
    }
    int rc = alias_set(name, val);
    free(val);
    return rc;
}

static int bi_xunalias(Cmd *cmd) {
    if (cmd->argc < 2) { errno = EINVAL; return -1; }
    return alias_unset(cmd->argv[1]);
}

static int bi_xwhich(Cmd *cmd) {
    if (cmd->argc < 2) {
        fprintf(stderr, "xwhich: usage: xwhich <name>...\n");
        return 2;
    }

    int status = 0;
    const char *path_env = getenv("PATH"); // may be NULL

    for (int i = 1; i < cmd->argc; i++) {
        const char *name = cmd->argv[i];
        if (!name || name[0] == '\0') continue;

        const char *a = alias_lookup(name);
        if (a) {
            printf("%s: alias -> %s\n", name, a);
            continue;
        }
        if (is_builtin(name)) {
            printf("%s: builtin\n", name);
            continue;
        }

        // search PATH manually
        if (!path_env) {
            printf("%s: not found\n", name);
            status = 1;
            continue;
        }

        int found = 0;
        char *dup = xstrdup(path_env);
        for (char *tok = strtok(dup, ":"); tok; tok = strtok(NULL, ":")) {
            char full[4096];
            snprintf(full, sizeof(full), "%s/%s", tok, name);
            if (access(full, X_OK) == 0) {
                printf("%s\n", full);
                found = 1;
                break;
            }
        }
        free(dup);

        if (!found) {
            printf("%s: not found\n", name);
            status = 1;
        }
    }

    fflush(stdout);
    return status;
}


static int bi_xsource(Cmd *cmd) {
    if (cmd->argc < 2) { errno = EINVAL; return -1; }
    const char *file = cmd->argv[1];
    FILE *f = fopen(file, "r");
    if (!f) return -1;
    char *line = NULL;
    size_t cap = 0;
    while (getline(&line, &cap, f) > 0) {
        // strip newline
        size_t n = strlen(line);
        while (n > 0 && (line[n-1] == '\n' || line[n-1] == '\r')) line[--n] = '\0';
        // skip empty/comment
        char *p = line;
        while (*p==' '||*p=='\t') p++;
        if (*p=='\0' || *p=='#') continue;

        Pipeline pl = {0};
        if (parse_line(p, &pl) != 0) {
            perror("parse");
            pipeline_free(&pl);
            continue;
        }
        pl.rawline = xstrdup(p);
        int st = exec_pipeline(&pl);
        pipeline_free(&pl);
        if (builtin_requests_exit()) break;
        (void)st;
    }
    free(line);
    fclose(f);
    return 0;
}

static int bi_xmenu(Cmd *cmd) {
    (void)cmd;
    printf("\033[1;36m=== Xhell Menu ===\033[0m\n");
    printf(" 1) files: xpwd / xls / xcd\n");
    printf(" 2) view:  xcat / xjournalctl\n");
    printf(" 3) copy/move/rm: xcp / xmv / xrm\n");
    printf(" 4) jobs: xjobs\n");
    printf(" 5) aliases: xalias\n");
    printf(" 6) help\n");
    printf(" 0) back\n");
    printf("Select: ");
    fflush(stdout);

    char buf[64];
    if (!fgets(buf, sizeof(buf), stdin)) return 0;
    int choice = atoi(buf);
    const char *run = NULL;
    switch (choice) {
        case 1: run = "xhelp"; break;
        case 2: run = "xjournalctl"; break;
        case 3: run = "xhelp"; break;
        case 4: run = "xjobs"; break;
        case 5: run = "xalias"; break;
        case 6: run = "xhelp"; break;
        default: return 0;
    }
    Pipeline pl = {0};
    if (parse_line(run, &pl) != 0) return -1;
    pl.rawline = xstrdup(run);
    int st = exec_pipeline(&pl);
    pipeline_free(&pl);
    return st;
}

static int bi_xjobs(Cmd *cmd) {
    (void)cmd;
    jobs_print();
    return 0;
}

static int bi_xfg(Cmd *cmd) {
    if (cmd->argc < 2) { errno = EINVAL; return -1; }
    int id = atoi(cmd->argv[1]);
    if (jobs_fg(id) < 0) return -1;
    return 0;
}

static int bi_xkill(Cmd *cmd) {
    if (cmd->argc < 2) { errno = EINVAL; return -1; }
    int id = atoi(cmd->argv[1]);
    if (jobs_kill(id) < 0) return -1;
    return 0;
}

int run_builtin(Cmd *cmd) {
    if (!cmd || cmd->argc == 0) { errno = EINVAL; return -1; }
    const char *name = cmd->argv[0];

    if (strcmp(name, "xpwd")==0) return bi_xpwd(cmd);
    if (strcmp(name, "xcd")==0) return bi_xcd(cmd);
    if (strcmp(name, "xls")==0) return bi_xls(cmd);
    if (strcmp(name, "xtouch")==0) return bi_xtouch(cmd);
    if (strcmp(name, "xecho")==0) return bi_xecho(cmd);
    if (strcmp(name, "xcat")==0) return bi_xcat(cmd);
    if (strcmp(name, "xcp")==0) return bi_xcp(cmd);
    if (strcmp(name, "xrm")==0) return bi_xrm(cmd);
    if (strcmp(name, "xmv")==0) return bi_xmv(cmd);
    if (strcmp(name, "xhistory")==0) return bi_xhistory(cmd);
    if (strcmp(name, "xtee")==0) return bi_xtee(cmd);
    if (strcmp(name, "xjournalctl")==0) return bi_xjournalctl(cmd);
    if (strcmp(name, "xhelp")==0) return bi_xhelp(cmd);
    if (strcmp(name, "xalias")==0) return bi_xalias(cmd);
    if (strcmp(name, "xunalias")==0) return bi_xunalias(cmd);
    if (strcmp(name, "xwhich")==0) return bi_xwhich(cmd);
    if (strcmp(name, "xsource")==0) return bi_xsource(cmd);
    if (strcmp(name, "xmenu")==0) return bi_xmenu(cmd);
    if (strcmp(name, "xjobs")==0) return bi_xjobs(cmd);
    if (strcmp(name, "xfg")==0) return bi_xfg(cmd);
    if (strcmp(name, "xkill")==0) return bi_xkill(cmd);

    if (strcmp(name, "quit")==0) {
        g_exit_requested = 1;
        return 0;
    }

    errno = ENOSYS;
    return -1;
}
