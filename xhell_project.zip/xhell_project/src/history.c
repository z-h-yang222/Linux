#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "history.h"
#include "util.h"

static char **g_hist = NULL;
static size_t g_n = 0, g_cap = 0;

static const char *g_builtins[] = {
    "xpwd","xcd","xls","xtouch","xecho","xcat","xcp","xrm","xmv",
    "xhistory","xtee","xjournalctl","quit",
    // extras
    "xhelp","xalias","xunalias","xwhich","xsource","xmenu",
    "xjobs","xfg","xkill",
    NULL
};

void hist_init(void) {
    g_hist = NULL; g_n = 0; g_cap = 0;
}

void hist_add(const char *line) {
    if (!line) return;
    if (g_n + 1 > g_cap) {
        g_cap = g_cap ? g_cap * 2 : 64;
        g_hist = realloc(g_hist, g_cap * sizeof(char*));
        if (!g_hist) { perror("realloc"); exit(1); }
    }
    g_hist[g_n++] = xstrdup(line);
}

void hist_print(void) {
    for (size_t i=0; i<g_n; i++) {
        printf("%zu  %s\n", i+1, g_hist[i]);
    }
}

void hist_close(void) {
    for (size_t i=0; i<g_n; i++) free(g_hist[i]);
    free(g_hist);
    g_hist = NULL; g_n = g_cap = 0;
}

const char **hist_builtin_list(void) {
    return g_builtins;
}
