#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <errno.h>
#include <string.h>
#include <stdarg.h>
#include <limits.h>

#include "logger.h"

static FILE *g_log = NULL;
static char g_path[PATH_MAX];

const char* log_path(void) { return g_path; }

static void ts(char *buf, size_t n) {
    struct timespec tp;
    clock_gettime(CLOCK_REALTIME, &tp);
    struct tm tm;
    localtime_r(&tp.tv_sec, &tm);
    snprintf(buf, n, "%04d-%02d-%02d %02d:%02d:%02d",
             tm.tm_year+1900, tm.tm_mon+1, tm.tm_mday,
             tm.tm_hour, tm.tm_min, tm.tm_sec);
}

void log_init(void) {
    const char *home = getenv("HOME");
    if (!home) home = ".";
    snprintf(g_path, sizeof(g_path), "%s/.xhell.log", home);
    g_log = fopen(g_path, "a");
    if (!g_log) {
        perror("fopen(~/.xhell.log)");
        // don't exit; still run
    }
}

void log_close(void) {
    if (g_log) fclose(g_log);
    g_log = NULL;
}

static void vlogf(const char *level, int saved_errno, const char *fmt, va_list ap) {
    if (!g_log) return;
    char t[64]; ts(t, sizeof(t));
    fprintf(g_log, "[%s] [%s] pid=%d ", t, level, (int)getpid());
    vfprintf(g_log, fmt, ap);
    if (saved_errno) fprintf(g_log, " (errno=%d: %s)", saved_errno, strerror(saved_errno));
    fputc('\n', g_log);
    fflush(g_log);
}

void log_info(const char *fmt, ...) {
    va_list ap; va_start(ap, fmt);
    vlogf("INFO", 0, fmt, ap);
    va_end(ap);
}

void log_error(int saved_errno, const char *fmt, ...) {
    va_list ap; va_start(ap, fmt);
    vlogf("ERROR", saved_errno, fmt, ap);
    va_end(ap);
}
