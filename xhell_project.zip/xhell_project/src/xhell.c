#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>
#include <pwd.h>
#include <limits.h>
#include <time.h>

#include "xhell.h"
#include "parser.h"
#include "exec.h"
#include "builtins.h"
#include "logger.h"
#include "history.h"
#include "jobs.h"
#include "alias.h"
#include "util.h"
#include "input.h"

static volatile sig_atomic_t g_got_sigchld = 0;
static int g_last_status = 0;
static long g_last_ms = 0;

static void on_sigchld(int signo) {
    (void)signo;
    g_got_sigchld = 1;
    jobs_on_child_exit();
}

static void install_signals(void) {
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = on_sigchld;
    sa.sa_flags = SA_RESTART | SA_NOCLDSTOP;
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGCHLD, &sa, NULL) < 0) {
        perror("sigaction(SIGCHLD)");
    }
    // interactive shell: parent ignores Ctrl-C; children restore defaults
    signal(SIGINT, SIG_IGN);
    signal(SIGQUIT, SIG_IGN);
}

static void banner(void) {
    printf("\033[1;36m===========================================\033[0m\n");
    printf("\033[1;36m   Xhell - a tiny bash-like shell (C)\033[0m\n");
    printf("\033[1;36m   Tips: xhelp | xalias | xmenu | xjobs\033[0m\n");
    printf("\033[1;36m===========================================\033[0m\n");
}

static void goodbye(void) {
    printf("\033[1;36m===========================================\033[0m\n");
    printf("\033[1;36m               Bye from Xhell\033[0m\n");
    printf("\033[1;36m===========================================\033[0m\n");
}

static void fmt_time(char out[16]) {
    time_t t = time(NULL);
    struct tm tm;
    localtime_r(&t, &tm);
    strftime(out, 16, "%H:%M:%S", &tm);
}

static void fmt_path(char out[PATH_MAX], const char *cwd) {
    const char *home = getenv("HOME");
    if (home && strncmp(cwd, home, strlen(home)) == 0) {
        snprintf(out, PATH_MAX, "~%s", cwd + strlen(home));
        if (out[1] == '\0') { out[1] = '/'; out[2] = '\0'; }
        return;
    }
    snprintf(out, PATH_MAX, "%s", cwd);
}

static char *xhell_prompt(void) {
    static char buf[PATH_MAX + 256];

    char cwd[PATH_MAX];
    if (!getcwd(cwd, sizeof(cwd))) snprintf(cwd, sizeof(cwd), "?");

    char shown[PATH_MAX];
    fmt_path(shown, cwd);

    char host[64] = {0};
    gethostname(host, sizeof(host) - 1);

    const char *user = "user";
    struct passwd *pw = getpwuid(getuid());
    if (pw && pw->pw_name) user = pw->pw_name;

    char now[16];
    fmt_time(now);

    char git[64] = {0};
    int have_git = (get_git_branch(git, sizeof(git)) == 0);

    int jobs = jobs_running_count();

#ifdef HAVE_READLINE
    // \001 \002 tell readline the enclosed bytes are non-printing
    #define NP1 "\001"
    #define NP2 "\002"
#else
    #define NP1 ""
    #define NP2 ""
#endif
    #define CSI(code) NP1 "\033[" code "m" NP2

    const char *st_text  = (g_last_status == 0) ? "OK" : "ERR";
    const char *st_color = (g_last_status == 0) ? CSI("1;32") : CSI("1;31");

    // layout:
    // [time user@host cwd (git) jobs] {OK/ERR status, ms}#
    char git_part[96] = {0};
    if (have_git) {
        snprintf(git_part, sizeof(git_part), " %s(%s)%s", CSI("1;35"), git, CSI("0"));
    }

    char jobs_part[64] = {0};
    if (jobs > 0) {
        snprintf(jobs_part, sizeof(jobs_part), " %sjobs:%d%s", CSI("1;33"), jobs, CSI("0"));
    }

    snprintf(
        buf, sizeof(buf),
        "%s[%s %s@%s %s%s%s]%s {%s%s %d%s, %ldms}%s#%s ",
        CSI("1;36"),
        now, user, host, shown,
        git_part, jobs_part,
        CSI("0"),
        st_color, st_text, g_last_status, CSI("0"), g_last_ms,
        CSI("1;36"),
        CSI("0")
    );

    #undef CSI
    #undef NP1
    #undef NP2
    return buf;
}

static long diff_ms(struct timespec a, struct timespec b) {
    long sec = (long)(b.tv_sec - a.tv_sec);
    long nsec = (long)(b.tv_nsec - a.tv_nsec);
    return sec * 1000 + nsec / 1000000;
}

int main(int argc, char **argv) {
    log_init();
    hist_init();
    jobs_init();
    alias_init();
    install_signals();
    xhell_input_init();

    banner();

    // script mode: ./xhell -f file
    FILE *script = NULL;
    if (argc == 3 && strcmp(argv[1], "-f") == 0) {
        script = fopen(argv[2], "r");
        if (!script) {
            perror("fopen(script)");
            return 1;
        }
    }

    while (1) {
        if (g_got_sigchld) {
            g_got_sigchld = 0;
            jobs_reap();
        }

        char *line = NULL;
        if (script) {
            size_t cap = 0;
            ssize_t n = getline(&line, &cap, script);
            if (n <= 0) break;
            while (n > 0 && (line[n-1] == '\n' || line[n-1] == '\r')) line[--n] = '\0';
            printf("%s%s\n", xhell_prompt(), line);
            fflush(stdout);
        } else {
            line = xhell_readline(xhell_prompt());
            if (!line) break; // EOF (Ctrl-D)
        }

        // trim
        char *p = line;
        while (*p == ' ' || *p == '\t') p++;
        if (*p == '\0') { free(line); continue; }

        // add history
        xhell_add_history(p);
        hist_add(p);
        log_info("CMD: %s", p);

        Pipeline pl = {0};
        if (parse_line(p, &pl) != 0) {
            int e = errno;
            perror("parse");
            log_error(e, "PARSE_ERROR: %s", p);
            free(line);
            continue;
        }
        pl.rawline = xstrdup(p);

        struct timespec t0, t1;
        clock_gettime(CLOCK_MONOTONIC, &t0);
        int status = exec_pipeline(&pl);
        clock_gettime(CLOCK_MONOTONIC, &t1);

        g_last_status = status;
        g_last_ms = diff_ms(t0, t1);

        log_info("EXIT: %d (%ldms)", status, g_last_ms);

        pipeline_free(&pl);
        free(line);

        if (builtin_requests_exit()) break;
    }

    if (script) fclose(script);
    goodbye();

    jobs_close();
    hist_close();
    alias_close();
    log_close();
    return 0;
}
