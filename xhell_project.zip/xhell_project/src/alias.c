#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/stat.h>

#include "alias.h"
#include "util.h"
#include "logger.h"

typedef struct {
    char *name;
    char *value;
} Alias;

static Alias *g_alias = NULL;
static int g_n = 0, g_cap = 0;

static const char *g_name_cache[1024]; // simple cache for completion

static void rebuild_name_cache(void) {
    int i = 0;
    for (; i < g_n && i < (int)(sizeof(g_name_cache)/sizeof(g_name_cache[0])) - 1; i++) {
        g_name_cache[i] = g_alias[i].name;
    }
    g_name_cache[i] = NULL;
}

static int valid_name(const char *s) {
    if (!s || !*s) return 0;
    if (!(isalpha((unsigned char)s[0]) || s[0]=='_')) return 0;
    for (const char *p = s; *p; p++) {
        if (!(isalnum((unsigned char)*p) || *p=='_' )) return 0;
    }
    return 1;
}

static int ensure_cap(int need) {
    if (g_cap >= need) return 0;
    int nc = g_cap ? g_cap * 2 : 16;
    while (nc < need) nc *= 2;
    Alias *na = realloc(g_alias, (size_t)nc * sizeof(Alias));
    if (!na) { errno = ENOMEM; return -1; }
    g_alias = na;
    g_cap = nc;
    return 0;
}

static int find_idx(const char *name) {
    for (int i=0;i<g_n;i++) {
        if (strcmp(g_alias[i].name, name) == 0) return i;
    }
    return -1;
}

void alias_init(void) {
    g_alias = NULL; g_n = 0; g_cap = 0;
    rebuild_name_cache();

    alias_ensure_default_rc();

    const char *home = getenv("HOME");
    if (home) {
        char path[4096];
        snprintf(path, sizeof(path), "%s/.xhellrc", home);
        if (alias_load_file(path) < 0) {
            // rc parsing shouldn't crash the shell; just log.
            log_error(errno, "Failed to load rc: %s", path);
        }
    }
}

void alias_close(void) {
    for (int i=0;i<g_n;i++) {
        free(g_alias[i].name);
        free(g_alias[i].value);
    }
    free(g_alias);
    g_alias = NULL; g_n = 0; g_cap = 0;
    rebuild_name_cache();
}

const char *alias_lookup(const char *name) {
    if (!name) return NULL;
    int idx = find_idx(name);
    if (idx < 0) return NULL;
    return g_alias[idx].value;
}

int alias_set(const char *name, const char *value) {
    if (!valid_name(name) || !value) { errno = EINVAL; return -1; }
    int idx = find_idx(name);
    if (idx >= 0) {
        char *nv = xstrdup(value);
        free(g_alias[idx].value);
        g_alias[idx].value = nv;
        rebuild_name_cache();
        return 0;
    }
    if (ensure_cap(g_n + 1) < 0) return -1;
    g_alias[g_n].name = xstrdup(name);
    g_alias[g_n].value = xstrdup(value);
    g_n++;
    rebuild_name_cache();
    return 0;
}

int alias_unset(const char *name) {
    if (!name) { errno = EINVAL; return -1; }
    int idx = find_idx(name);
    if (idx < 0) { errno = ENOENT; return -1; }
    free(g_alias[idx].name);
    free(g_alias[idx].value);
    for (int i=idx;i<g_n-1;i++) g_alias[i] = g_alias[i+1];
    g_n--;
    rebuild_name_cache();
    return 0;
}

void alias_print(void) {
    for (int i=0;i<g_n;i++) {
        printf("alias %s=\"%s\"\n", g_alias[i].name, g_alias[i].value);
    }
}

// --- rc parsing ---

static char *trim(char *s) {
    while (*s && isspace((unsigned char)*s)) s++;
    char *e = s + strlen(s);
    while (e > s && isspace((unsigned char)e[-1])) e--;
    *e = '\0';
    return s;
}

static int parse_alias_line(const char *line) {
    // line expected: alias NAME="VALUE"  (VALUE can contain spaces)
    const char *p = line;
    while (*p && isspace((unsigned char)*p)) p++;
    if (strncmp(p, "alias", 5) != 0 || !(p[5]==' '||p[5]=='\t')) { errno = EINVAL; return -1; }
    p += 5;
    while (*p && isspace((unsigned char)*p)) p++;
    const char *name_start = p;
    while (*p && (isalnum((unsigned char)*p) || *p=='_')) p++;
    size_t name_len = (size_t)(p - name_start);
    if (name_len == 0) { errno = EINVAL; return -1; }
    char name[256];
    if (name_len >= sizeof(name)) { errno = E2BIG; return -1; }
    memcpy(name, name_start, name_len);
    name[name_len] = '\0';

    while (*p && isspace((unsigned char)*p)) p++;
    if (*p != '=') { errno = EINVAL; return -1; }
    p++;
    while (*p && isspace((unsigned char)*p)) p++;

    char quote = 0;
    if (*p == '\'' || *p == '"') { quote = *p; p++; }
    const char *val_start = p;
    if (quote) {
        while (*p && *p != quote) p++;
        if (*p != quote) { errno = EINVAL; return -1; }
    } else {
        // unquoted: read to end
        while (*p) p++;
    }
    size_t val_len = (size_t)(p - val_start);
    char *val = (char*)xcalloc(val_len + 1, 1);
    memcpy(val, val_start, val_len);
    val[val_len] = '\0';

    int rc = alias_set(name, val);
    free(val);
    return rc;
}

static int parse_unalias_line(const char *line) {
    const char *p = line;
    while (*p && isspace((unsigned char)*p)) p++;
    if (strncmp(p, "unalias", 7) != 0 || !(p[7]==' '||p[7]=='\t')) { errno = EINVAL; return -1; }
    p += 7;
    while (*p && isspace((unsigned char)*p)) p++;
    if (!*p) { errno = EINVAL; return -1; }
    char name[256];
    snprintf(name, sizeof(name), "%s", p);
    // trim end spaces
    for (int i=(int)strlen(name)-1; i>=0 && isspace((unsigned char)name[i]); i--) name[i]='\0';
    // ignore not found
    int idx = find_idx(name);
    if (idx >= 0) return alias_unset(name);
    return 0;
}

int alias_load_file(const char *path) {
    if (!path) { errno = EINVAL; return -1; }
    FILE *f = fopen(path, "r");
    if (!f) return -1;

    char *line = NULL;
    size_t cap = 0;
    int rc = 0;
    while (getline(&line, &cap, f) > 0) {
        char *t = trim(line);
        if (*t == '\0' || *t == '#') continue;
        if (strncmp(t, "alias", 5) == 0) {
            if (parse_alias_line(t) < 0) {
                log_error(errno, "Bad rc line (alias): %s", t);
            }
        } else if (strncmp(t, "unalias", 7) == 0) {
            if (parse_unalias_line(t) < 0) {
                log_error(errno, "Bad rc line (unalias): %s", t);
            }
        } else {
            // ignore unknown lines
        }
    }
    free(line);
    fclose(f);
    rebuild_name_cache();
    return rc;
}

void alias_ensure_default_rc(void) {
    const char *home = getenv("HOME");
    if (!home) return;
    char path[4096];
    snprintf(path, sizeof(path), "%s/.xhellrc", home);
    struct stat st;
    if (stat(path, &st) == 0) return;

    FILE *f = fopen(path, "w");
    if (!f) return;
    fprintf(f, "# Xhell rc file\n");
    fprintf(f, "# Example aliases:\n");
    fprintf(f, "alias ll=\"xls -l\"\n");
    fprintf(f, "alias ..=\"xcd ..\"\n");
    fprintf(f, "alias la=\"xls -l .\"\n");
    fclose(f);
}

const char **alias_name_list(void) {
    rebuild_name_cache();
    return g_name_cache;
}
