#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/wait.h>
#include <errno.h>
#include <unistd.h>

#include "jobs.h"
#include "util.h"

typedef enum { JOB_RUNNING, JOB_DONE } job_state;

typedef struct {
    int id;
    pid_t pgid;
    job_state st;
    int exitcode; // if done
    char *cmd;
} Job;

static Job *g_jobs = NULL;
static int g_n = 0, g_cap = 0;
static volatile sig_atomic_t g_need_reap = 0;
static int g_next_id = 1;

void jobs_init(void) {
    g_jobs = NULL; g_n = 0; g_cap = 0; g_need_reap = 0;
}

void jobs_on_child_exit(void) {
    g_need_reap = 1;
}

static void jobs_mark_done(pid_t pid, int status) {
    // map pid -> pgid
    pid_t pgid = getpgid(pid);
    if (pgid < 0) return;
    for (int i=0;i<g_n;i++) {
        if (g_jobs[i].pgid == pgid && g_jobs[i].st == JOB_RUNNING) {
            g_jobs[i].st = JOB_DONE;
            if (WIFEXITED(status)) g_jobs[i].exitcode = WEXITSTATUS(status);
            else if (WIFSIGNALED(status)) g_jobs[i].exitcode = 128 + WTERMSIG(status);
            else g_jobs[i].exitcode = 1;
        }
    }
}

void jobs_reap(void) {
    if (!g_need_reap) return;
    g_need_reap = 0;
    int status;
    pid_t pid;
    while ((pid = waitpid(-1, &status, WNOHANG)) > 0) {
        jobs_mark_done(pid, status);
    }
}

int jobs_add(pid_t pgid, const char *cmdline) {
    if (g_n + 1 > g_cap) {
        g_cap = g_cap ? g_cap * 2 : 16;
        g_jobs = realloc(g_jobs, g_cap * sizeof(Job));
        if (!g_jobs) { perror("realloc"); exit(1); }
    }
    Job *j = &g_jobs[g_n++];
    j->id = g_next_id++;
    j->pgid = pgid;
    j->st = JOB_RUNNING;
    j->exitcode = 0;
    j->cmd = xstrdup(cmdline ? cmdline : "");
    return j->id;
}

void jobs_print(void) {
    jobs_reap();
    printf("\033[1;33mID   STATE     PGID     COMMAND\033[0m\n");
    for (int i=0;i<g_n;i++) {
        Job *j = &g_jobs[i];
        const char *st = (j->st == JOB_RUNNING) ? "Running" : "Done";
        const char *c = (j->st == JOB_RUNNING) ? "\033[1;32m" : "\033[1;90m";
        printf("[%d]  %s%-7s\033[0m  %-7d %s", j->id, c, st, (int)j->pgid, j->cmd);
        if (j->st == JOB_DONE) printf(" (exit=%d)", j->exitcode);
        printf("\n");
    }
}

static Job* find_job(int id) {
    for (int i=0;i<g_n;i++) if (g_jobs[i].id == id) return &g_jobs[i];
    return NULL;
}

int jobs_fg(int job_id) {
    Job *j = find_job(job_id);
    if (!j) { errno = ESRCH; return -1; }
    // bring to foreground by waiting on pgid
    int status;
    pid_t pid;
    while ((pid = waitpid(-j->pgid, &status, 0)) > 0) {
        jobs_mark_done(pid, status);
    }
    return 0;
}

int jobs_kill(int job_id) {
    Job *j = find_job(job_id);
    if (!j) { errno = ESRCH; return -1; }
    if (kill(-j->pgid, SIGTERM) < 0) return -1;
    return 0;
}

int jobs_running_count(void) {
    jobs_reap();
    int n = 0;
    for (int i=0;i<g_n;i++) if (g_jobs[i].st == JOB_RUNNING) n++;
    return n;
}

void jobs_close(void) {
    for (int i=0;i<g_n;i++) free(g_jobs[i].cmd);
    free(g_jobs);
    g_jobs = NULL; g_n = g_cap = 0;
}

