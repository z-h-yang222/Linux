#define _GNU_SOURCE
#ifndef HAVE_READLINE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "input.h"

// Simple fallback: getline + prompt. No arrow-key history, no completion.
void xhell_input_init(void) {}

char *xhell_readline(const char *prompt) {
    fputs(prompt, stdout);
    fflush(stdout);

    char *line = NULL;
    size_t cap = 0;
    ssize_t n = getline(&line, &cap, stdin);
    if (n <= 0) {
        free(line);
        return NULL;
    }
    // strip newline
    while (n > 0 && (line[n-1] == '\n' || line[n-1] == '\r')) {
        line[n-1] = '\0';
        n--;
    }
    return line;
}

void xhell_add_history(const char *line) {
    (void)line;
}

#endif
