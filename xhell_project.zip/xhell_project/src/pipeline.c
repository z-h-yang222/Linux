#include <stdlib.h>
#include <string.h>
#include "xhell.h"

void pipeline_free(Pipeline *p) {
    if (!p || !p->cmds) return;
    for (int i = 0; i < p->ncmds; i++) {
        Cmd *c = &p->cmds[i];
        if (c->argv) {
            for (int j = 0; c->argv[j]; j++) free(c->argv[j]);
            free(c->argv);
        }
        free(c->in_file);
        free(c->out_file);
        free(c->err_file);
    }
    free(p->cmds);
    p->cmds = NULL;
    p->ncmds = 0;
    free(p->rawline);
    p->rawline = NULL;
}
