# Xhell (Linux 期末大作业)

本项目实现一个模仿 bash 的交互式 shell：`xhell`（禁用 system()）。

## 依赖
- gcc / make
- GNU readline（用于上下键历史、编辑、Tab 补全）
  - Ubuntu/Debian: `sudo apt-get install libreadline-dev`

## 编译
```bash
make
```

## 运行
```bash
./xhell
# 或运行脚本
./xhell -f script.txt
```

## 特色增强（附加项）
- 彩色 prompt、欢迎界面
- readline：上下键历史、Ctrl-R 搜索历史、Tab 自动补全（内置命令+文件名）
- 后台任务与任务管理：`&`、`xjobs`、`xfg`、`xkill`

## 额外“卷”起来的功能（加分项）
- **炫酷 prompt**：显示时间、user@host、cwd、git 分支、后台任务数、上条命令耗时/退出码
- **xalias / xunalias**：支持 `~/.xhellrc`，启动自动加载（默认会生成示例 rc）
- **xwhich**：查看一个命令到底是 alias / builtin / PATH 中的外部命令
- **xsource**：在当前 shell 内执行脚本文件（相当于 bash 的 source）
- **xmenu**：交互式菜单（演示/验收非常好用）
- **更强补全**：内置命令 + alias + PATH 可执行命令 + 文件名补全

日志文件：`~/.xhell.log`，可用 `xjournalctl` 查看。
