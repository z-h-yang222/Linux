#pragma once
#include "xhell.h"

// Parse a command line into a Pipeline.
// Returns 0 on success; -1 on parse error (errno set).
int parse_line(const char *line, Pipeline *out);

