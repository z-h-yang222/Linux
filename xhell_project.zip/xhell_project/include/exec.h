#pragma once
#include "xhell.h"

// Execute a pipeline. Returns last command exit status (like bash).
int exec_pipeline(Pipeline *p);

