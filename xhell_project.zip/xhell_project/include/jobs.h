#pragma once
#include <sys/types.h>

void jobs_init(void);
void jobs_on_child_exit(void); // called in SIGCHLD handler (safe-ish: sets flags)
void jobs_reap(void);          // call in main loop to update jobs

int jobs_add(pid_t pgid, const char *cmdline);
void jobs_print(void);
int jobs_fg(int job_id);
int jobs_kill(int job_id);

// Number of running background jobs.
int jobs_running_count(void);

void jobs_close(void);
