#pragma once
#include <stddef.h>

void hist_init(void);
void hist_add(const char *line);
void hist_print(void);
void hist_close(void);

// For tab-completion: returns list of builtin names (NULL-terminated)
const char **hist_builtin_list(void);

