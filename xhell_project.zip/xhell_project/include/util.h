#pragma once
#include <stddef.h>

char *xstrdup(const char *s);
void *xcalloc(size_t n, size_t sz);

// Split a shell-like string into words. Supports single/double quotes.
// No escapes; good enough for aliases/prompt helpers.
// Returns 0 on success; caller frees each argv[i] and the argv array.
int split_words(const char *line, char ***out_argv, int *out_argc, int max_args);

// Git branch (best-effort). Returns 0 if found, -1 otherwise.
int get_git_branch(char *out, size_t out_sz);
