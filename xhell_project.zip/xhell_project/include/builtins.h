#pragma once
#include "xhell.h"

// return 1 if cmd is a builtin
int is_builtin(const char *name);

// run builtin in current process; returns exit status (0 ok)
int run_builtin(Cmd *cmd);

// builtins that must run in parent (affect shell state)
int is_parent_only_builtin(const char *name);

// xcd/quit etc can ask the shell to stop
int builtin_requests_exit(void);  // 1 if last builtin requested exit

