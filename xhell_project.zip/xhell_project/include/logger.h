#pragma once
#include <stdarg.h>

void log_init(void);
void log_close(void);

// log an info line (printf-like)
void log_info(const char *fmt, ...);
// log an error line (printf-like), includes errno string when errno != 0
void log_error(int saved_errno, const char *fmt, ...);

// path to log file (owned by logger; do not free)
const char* log_path(void);

