#pragma once
// Returns malloc'ed line without trailing newline; NULL on EOF.
char *xhell_readline(const char *prompt);
// Adds history entry (if supported)
void xhell_add_history(const char *line);
// Optional init hook for completion (no-op in simple mode)
void xhell_input_init(void);
