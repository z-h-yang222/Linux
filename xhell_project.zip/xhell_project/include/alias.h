#pragma once

// Simple alias engine (similar to bash alias) + rc loader.
// Aliases expand the FIRST word of each simple command.

void alias_init(void);
void alias_close(void);

// Returns alias value string, or NULL if not found.
const char *alias_lookup(const char *name);

// Set/unset alias. Return 0 on success, -1 on error (errno set).
int alias_set(const char *name, const char *value);
int alias_unset(const char *name);

// Print all aliases to stdout.
void alias_print(void);

// Load alias entries from a rc file.
// Supported lines:
//   alias ll="xls -l"
//   unalias ll
//   # comment
int alias_load_file(const char *path);

// Ensure ~/.xhellrc exists; create a friendly default if missing.
void alias_ensure_default_rc(void);

// For completion UI: get a NULL-terminated list of alias names.
// Returned pointers are valid until alias_close()/alias_set()/alias_unset().
const char **alias_name_list(void);
