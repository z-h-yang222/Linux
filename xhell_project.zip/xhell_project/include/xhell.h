#pragma once
#define _GNU_SOURCE

#include <stdbool.h>
#include <stddef.h>

#define XHELL_MAX_PIPE 32
#define XHELL_MAX_ARGS 128

typedef struct {
    char **argv;          // NULL-terminated
    int   argc;

    char *in_file;        // < file
    char *out_file;       // > / >>
    int   out_append;     // 1 if >>
    char *err_file;       // 2> / 2>>
    int   err_append;     // 1 if 2>>
} Cmd;

typedef struct {
    Cmd  *cmds;
    int   ncmds;
    bool  background;
    char *rawline;        // for history/log
} Pipeline;

void pipeline_free(Pipeline *p);

